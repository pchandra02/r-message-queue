library(testthat)
library(messageQueue)


test_package("messageQueue")

#test_dir("inst/tests/", reporter="minimal");

#test_file("inst/tests/test-x-produce-consume.R");
#test_file("inst/tests/test-producer.R");
