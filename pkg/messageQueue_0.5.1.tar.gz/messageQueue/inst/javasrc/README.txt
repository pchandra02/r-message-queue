Updated source and structure managed here as a maven project:
https://code.google.com/p/r-message-queue/

Matt.